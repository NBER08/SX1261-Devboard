*PADS-LIBRARY-PART-TYPES-V9*

114993390 114993390 I ANA 7 1 0 0 0
TIMESTAMP 2026.05.22.13.07.41
"Mouser Part Number" 713-114993390
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Seeed-Studio/114993390?qs=NeOn4crkEuu9JWV37oJsXg%3D%3D
"Manufacturer_Name" Seeed Studio
"Manufacturer_Part_Number" 114993390
"Description" RF Modules Wio-SX1262 Wireless Module (Bulk), SX1262 embedded, supports LoRa&LoRaWAN on EU868 & US915
"Datasheet Link" 
"Geometry.Height" 3.15mm
GATE 1 12 0
114993390
1 0 U RF_SW_
2 0 U MISO
3 0 U MOSI
4 0 U SCK
5 0 U NRST
6 0 U NSS
7 0 U GND_1
8 0 U VCC
9 0 U ANT
10 0 U GND_2
11 0 U BUSY
12 0 U DIO1

*END*
*REMARK* SamacSys ECAD Model
20394896/1748721/2.50/12/3/Integrated Circuit
